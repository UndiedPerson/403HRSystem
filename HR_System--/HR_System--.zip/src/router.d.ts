import type { Router } from 'vue-router';
declare const router: Router;
export default router;
