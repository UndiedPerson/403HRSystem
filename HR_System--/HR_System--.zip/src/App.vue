<!-- src/App.vue -->
<script setup>
import Login from './components/Login.vue'
</script>

<template>
  <div id="app">
    <Login />
  </div>
</template>

<style scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  color: #2c3e50;
  padding: 50px;
}
</style>
