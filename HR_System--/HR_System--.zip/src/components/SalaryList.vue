<!-- <template>
    <div>
      <h2>Salary List</h2>
      <table>
        <thead>
          <tr>
            <th>Employee Name</th>
            <th>Salary</th>
            <th>Payment Date</th>
            <th> -->