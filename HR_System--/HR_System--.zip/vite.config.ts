import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  base: '/HrSystem_project/Human-Resource-Management-System_System_Analysis_and_Design_Project/HR_System--/',
})
